import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class shapes extends PApplet {
  public void setup() {

fill(255,255,0);
rect(25,25,125,125);
rect(180,25,125,125,12);
rect(340,25,125,125,12,20,30,50);
rect(500,50,115,75);
fill(255,0,0);
ellipse(85,250,125,125);
ellipse(240,240,125,75);
ellipse(400,240,75,125);
fill(3,12,255);
triangle(560,190,615,300,500,300);
triangle(40,335,140,455,25,415);
fill(0,225,230);
quad(180,340,300,340,300,380,180,450);
quad(400,340,430,400,400,450,370,400);
quad(500,340,615,400,500,450,560,400);
    noLoop();
  }

  public void settings() { size(650,550); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "shapes" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
