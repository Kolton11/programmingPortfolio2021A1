import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.math.*; 
import java.util.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Calculator extends PApplet {

Button[] numButtons = new Button[10];
Button[] opButtons = new Button[12];
String dVal;
String op ="";
boolean left = true;
float r = 0.0f;
float l = 0.0f;
float result = 0.0f;
int currentNum = 0;
DivInfo di = new DivInfo(currentNum);

public void setup() {
  
  dVal = "0";
  numButtons[0] = new Button(40, 90, 40, 40, "0", 0xff6993B3, 0xffC9E8FF );
  numButtons[1] = new Button(90, 90, 40, 40, "1", 0xff6993B3, 0xffC9E8FF);
  numButtons[2] = new Button(140, 90, 40, 40, "2", 0xff6993B3, 0xffC9E8FF);
  numButtons[3] = new Button(190, 90, 40, 40, "3", 0xff6993B3, 0xffC9E8FF);
  numButtons[4] = new Button(240, 90, 40, 40, "4", 0xff6993B3, 0xffC9E8FF);
  numButtons[5] = new Button(290, 90, 40, 40, "5", 0xff6993B3, 0xffC9E8FF);
  numButtons[6] = new Button(40, 130, 40, 40, "6", 0xff6993B3, 0xffC9E8FF);
  numButtons[7] = new Button(100, 130, 40, 40, "7", 0xff6993B3, 0xffC9E8FF );
  numButtons[8] = new Button(160, 130, 40, 40, "8", 0xff6993B3, 0xffC9E8FF);
  numButtons[9] = new Button(220, 130, 40, 40, "9", 0xff6993B3, 0xffC9E8FF);
  opButtons[0] = new Button(280, 130, 40, 40, "C", 0xff6993B3, 0xffC9E8FF);
  opButtons[1] = new Button(40, 180, 40, 40, "+", 0xff6993B3, 0xffC9E8FF);
  opButtons[2] = new Button(40, 230, 40, 40, "x", 0xff6993B3, 0xffC9E8FF);
  opButtons[3] = new Button(100, 180, 40, 40, "-", 0xff6993B3, 0xffC9E8FF);
  opButtons[4] = new Button(100, 230, 40, 40, "÷", 0xff6993B3, 0xffC9E8FF);
  opButtons[5] = new Button(160, 180, 40, 40, ".", 0xff6993B3, 0xffC9E8FF);
  opButtons[6] = new Button(160, 230, 40, 40, "±", 0xff6993B3, 0xffC9E8FF);
  opButtons[7] = new Button(220, 180, 40, 40, "%", 0xff6993B3, 0xffC9E8FF);
  opButtons[8] = new Button(280, 180, 40, 40, "=", 0xff6993B3, 0xffC9E8FF);
  opButtons[9] = new Button(220, 230, 40, 40, "sin", 0xff6993B3, 0xffC9E8FF);
  opButtons[10] = new Button(280, 230, 40, 40, "cos", 0xff6993B3, 0xffC9E8FF);
  opButtons[11] = new Button(160, 270, 40, 40, "Rand", 0xff6993B3, 0xffC9E8FF );
}

public void draw() {
  background(127);

  updateDisplay();

  for (int i=0; i<numButtons.length; i++) {
    numButtons[i].hover(mouseX, mouseY);
    numButtons[i].display();
  }
  for (int i=0; i<opButtons.length; i++) {
    opButtons[i].hover(mouseX, mouseY);
    opButtons[i].display();
  }
  callDivInfo();
}

public void updateDisplay() {
  rectMode(CORNER);
  fill(80);
  rect(10, 10, width-20, 60);
  fill(255);
  textAlign(RIGHT);

  if (dVal.length()<13) {
    textSize(32);
  } else if (dVal.length()<14) {
    textSize(28);
  } else if (dVal.length()<15) {
    textSize(26);
  } else if (dVal.length()<17) {
    textSize(24);
  } else if (dVal.length()<19) {
    textSize(22);
  } else if (dVal.length()<21) {
    textSize(20);
  } else if (dVal.length()<23) {
    textSize(18);
  } else if (dVal.length()<25) {
    textSize(16);
  } else {
    textSize(14);
  }
  text(dVal, width-15, 50);

  fill(127);
  rectMode(CORNER);
  rect(10, 350, width-20, 60);

  textSize(9);
  textAlign(LEFT);
  fill(255);
  text("L:" + l + " R:" + r + " Op:" + op, 15, 350);
  text("Result:" + result + " Left:" + left, 15, 355);

  fill(127); 
  rectMode(CORNER);
  rect(10, 350, width-20, 180);

  textSize(9);
  textAlign(LEFT);
  fill(255);
  if (currentNum<34) {
    text("Factorial:" + di.factorial(currentNum), 15, 355);
  } else {
    text("Factorial too large to display!", 15, 290);
  }
  if (currentNum<10000000) {
    if (currentNum<1006 && currentNum>0) {
      text("This prime:" + di.primeList.get(currentNum), 15, 307);
    } else {
      text("This prime: too large", 15, 350);
    }
    text("Sum of Divisors:" + di.divSum(currentNum) + " or " + di.divSum2(currentNum), 15, 360);
    textLeading(10);
    text("Divisors:" + di.getDivs(currentNum), 15, 350, 250, 40);
  } else {
    text("Sum of Divisors: too large", 15, 319);
    textLeading(10);
    text("Divisors: too large", 15, 320, 250, 30);
  }
}


public void mouseReleased() {
  for (int i=0; i<numButtons.length; i++) {
    if (numButtons[i].over && dVal.length()<20) {
      handleEvent(numButtons[i].val, true);
    }
  }
  for (int i=0; i<opButtons.length; i++) {
    if (opButtons[i].over) {
      handleEvent(opButtons[i].val, false);
    }
  }
}

public void keyPressed() {
  println("KEY" + key + "keyCode:" + keyCode);

  if (key == '0') {
    handleEvent("0", true);
  } else if (key == '1') {
    handleEvent("1", true);
  } else if (key == '2') {
    handleEvent("2", true);
  } else if (key == '3') {
    handleEvent("3", true);
  } else if (key == '4') {
    handleEvent("4", true);
  } else if (key == '5') {
    handleEvent("5", true);
  } else if (key == '6') {
    handleEvent("6", true);
  } else if (key == '7') {
    handleEvent("7", true);
  } else if (key == '8') {
    handleEvent("8", true);
  } else if (key == '9') {
    handleEvent("9", true);
  } else if (key == '+') {
    handleEvent("+", false);
  } else if (key == '-') {
    handleEvent("-", false);
  } else if (key == '*') {
    handleEvent("x", false);
  } else if (key == '/') {
    handleEvent("÷", false);
  } else if (key == '.') {
    handleEvent(".", false);
  } else if (key == 'C') {
    handleEvent("C", false);
  } else if (key == 10) {
    if (keyCode == ENTER || keyCode == RETURN) {
      handleEvent("=", false);
    }
  } else if (keyCode == 27) {
    key = 0;
    if (key == 0) {
      handleEvent("C", false);
    }
  }
}

public String handleEvent(String val, boolean num) {
  if (left & num) { // Left Number
    if (dVal.equals("0") || result == l) {
      dVal = (val);
      l = PApplet.parseFloat(dVal);
    } else {
      dVal += (val);
      l = PApplet.parseFloat(dVal);
    }
  } else if (!left && num) {
    if (dVal.equals("0") || result == l) {
      dVal = (val);
      r = PApplet.parseFloat(dVal);
    } else { 
      dVal += (val);
      r = PApplet.parseFloat(dVal);
    }
  } else if (val.equals("C")) {
    dVal = "0";
    result = 0.0f;
    left = true;
    r = 0.0f;
    l = 0.0f;
    op = "";
  } else if (val.equals("+")) {
    if (!left) {
      performCalc();
    } else {
      op = "+";
      left = false;
      dVal = "0";
    }
  } else if (val.equals("-")) {
    op = "-";
    left = false;
    dVal = "0";
  } else if (val.equals("x")) {
    op = "x";
    left = false;
    dVal = "0";
  } else if (val.equals("÷")) {
    op = "÷";
    left = false;
    dVal = "0";
  } else if (val.equals("%")) {
    if (left) {
      l *= 0.1f;
      dVal = str(l);
    } else {
      r *= 0.1f;
      dVal = str(r);
    }
  } else if (val.equals("±")) {
    if (left) {
      l *= -1;
      dVal = str(l);
    } else {
      r *= -1;
      dVal = str(r);
    }
  } else if (val.equals("sin")) {
    if (left) {
      l = sin(radians(l));
      dVal = str(l);
    } else {
      r = sin(radians(r));
      dVal = str(r);
    }
  } else if (val.equals("cos")) {
    if (left) {
      l = cos(radians(l));
      dVal = str(l);
    } else {
      r = cos(radians(r));
      dVal = str(r);
    }
  } else if (val.equals("Rand")) {
    if (left) {
      l = random(0, 1);
      dVal = str(l);
    } else {
      r = random(0, 1);
      dVal = str(r);
    }
  } else if (val.equals(".") && !dVal.contains(".")) {
    dVal += (val);
  } else if (val.equals("=")) {
    performCalc();
  }
  return val;
}

public void performCalc() {
  if (op.equals("+")) {
    result = l + r;
  } else if (op.equals("-")) {
    result = l - r;
  } else if (op.equals("x")) {
    result = l * r;
  } else if (op.equals("÷")) {
    result = l / r;
  }
  l = result;
  dVal = str(result);
  left = true;
}


public void callDivInfo() {
  currentNum = PApplet.parseInt(dVal.replaceAll("\\.0*$", ""));
  if (!dVal.contains(".") || dVal.contains(".0")) {
    // Check for Prime
    if (currentNum < 1) {
      noFill();
      stroke(0xffBABACF);
      ellipse(20, 20, 15, 15);
      fill(0xffBABACF);
      text("p", 20, 25);
    } else {
      if (di.isPrime(currentNum)) {
        fill(0xffE3DBB6);
        noStroke();
        ellipse(20, 20, 15, 15);
        fill(0);
        text("p", 20, 25);
      } else {
        noFill();
        stroke(0xffBABACF);
        ellipse(20, 20, 15, 15);
        fill(0xffBABACF);
        text("p", 20, 25);
      }
    }

    // Check for Fib Number
    if (currentNum < 1) {
      noFill();
      stroke(0xffBABACF);
      ellipse(40, 20, 15, 15);
      fill(0xffBABACF);
      text("F", 40, 25);
    } else {
      if (di.isFibonacci(currentNum)) {
        fill(0xffE3DBB6);
        noStroke();
        ellipse(40, 20, 15, 15);
        fill(0);
        text("F", 40, 25);
      } else {
        noFill();
        stroke(0xffBABACF);
        ellipse(40, 20, 15, 15);
        fill(0xffBABACF);
        text("F", 40, 25);
      }
    }

    // Check for Catalan Number
    if (currentNum < 1) {
      noFill();
      stroke(0xffBABACF);
      ellipse(60, 20, 15, 15);
      fill(0xffBABACF);
      text("C", 60, 25);
    } else {
      if (di.isCatalan(currentNum)) {
        fill(0xffE3DBB6);
        noStroke();
        ellipse(60, 20, 15, 15);
        fill(0);
        text("C", 60, 25);
      } else {
        noFill();
        stroke(0xffBABACF);
        ellipse(60, 20, 15, 15);
        fill(0xffBABACF);
        text("C", 60, 25);
      }
    }

    // Check for Bell Number
    if (currentNum < 1) {
      noFill();
      stroke(0xffBABACF);
      ellipse(80, 20, 15, 15);
      fill(0xffBABACF);
      text("B", 80, 25);
    } else {
      if (di.isBell(currentNum)) {
        fill(0xffE3DBB6);
        noStroke();
        ellipse(80, 20, 15, 15);
        fill(0);
        text("B", 80, 25);
      } else {
        noFill();
        stroke(0xffBABACF);
        ellipse(80, 20, 15, 15);
        fill(0xffBABACF);
        text("B", 80, 25);
      }
    }

    // Check for Perfect Number
    if (currentNum < 1) {
      noFill();
      stroke(0xffBABACF);
      ellipse(100, 20, 15, 15);
      fill(0xffBABACF);
      text("P", 100, 25);
    } else {
      if (di.divSum(currentNum) == currentNum) {
        fill(0xffE3DBB6);
        noStroke();
        ellipse(100, 20, 15, 15);
        fill(0);
        text("P", 100, 25);
      } else {
        noFill();
        stroke(0xffBABACF);
        ellipse(100, 20, 15, 15);
        fill(0xffBABACF);
        text("P", 100, 25);
      }
    }
  } else {
    noFill();
    stroke(0xffBABACF);
    ellipse(20, 20, 15, 15);
    fill(0xffBABACF);
    text("P", 20, 25);
    noFill();
    stroke(0xffBABACF);
    ellipse(40, 20, 15, 15);
    fill(0xffBABACF);
    text("F", 40, 25);
    noFill();
    stroke(0xffBABACF);
    ellipse(60, 20, 15, 15);
    fill(0xffBABACF);
    text("C", 60, 25);
    noFill();
    stroke(0xffBABACF);
    ellipse(80, 20, 15, 15);
    fill(0xffBABACF);
    text("B", 80, 25);
  }
}
class Button {    
  // Member Variables
  int x, y, w, h;
  String val;
  boolean over;
  int c1, c2;

  // Constructor
  Button(int x, int y, int w, int h, String val, int c1, int c2) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.val = val;
    this.c1 = c1;
    this.c2 = c2;
  }

  // Display the Button
  public void display() {
    stroke(0);
      if (over) {
        fill(c2);
      } else {
        fill(c1);
      }
      rectMode(CENTER);
      rect(x, y, w, h, 10);
      fill(255);
      textAlign(CENTER);
      textSize(17);
      text(val, x, y+10);
  }
  // Edge Detection
  public void hover(int tempX, int tempY) {
    over = tempX>x-w/2 && tempX<x+w/2 && tempY>y-h/2 && tempY<y+h/2;
  }
}


class DivInfo {
  int num;
  ArrayList<Integer> primeList;
  private int[] catalan;
  private int[] bell;
  String nextPrime = "";
  String prevPrime = "";


  DivInfo(int num) {
    this.num = num;
    allPrimesLessThanN(8000);
    catalan = new int[10];
    bell = new int[10]; 
    catalan = makeCatalan();
    bellGenerator();
  }

  // Returns divisors
  public String getDivs(int num) {
    String result = "";
    for (int i=1; i<=num; i++) {
      if (num%i==0) {
        result+=i+" ";
      }
    }
    return result;
  }

  // Returns factors
  public String getFactors(int num) {
    String result = "";
    for (int f = 2; f*f <= num; f++) {
      while (num % f == 0) {
        result+=f + " "; 
        num/=f;
      }
    }
    return result = result  + num;
  }

  // Returns sum of divisors (traditional)
  public int divSum(int num) {
    int result = 0;
    for (int i=2; i<=sqrt(num); i++) {
      if (num%i==0) {
        if (i==(num/i))
          result += i;
        else
          result += (i + num/i);
      }
    }
    return (result + 1);
  }

  // returns divisor sum with itself
  public int divSum2(int num) {
    int result = 0;
    for (int i=2; i<=sqrt(num); i++) {
      if (num%i==0) {
        if (i==(num/i))
          result += i;
        else
          result += (i + num/i);
      }
    }
    return (result + 1 + num);
  }

  // Returns prime 
  public boolean isPrime(int num) { 
    int squarert = PApplet.parseInt(sqrt(num)) + 1; 
    for (int i = 2; i < squarert; i++) { 
      if (num % i == 0) {
        return false;
      }
    } 
    return true;
  }

  // Returns a customizable base number equivilant
  public String convert ( int number, int base )
  {
    return convert(number, base, 0, "" );
  }

  private String convert ( int number, int base, int position, String result )
  {
    char symbols[] = new char[] { '0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T' };

    if ( number < Math.pow(base, position + 1) )
    {
      return symbols[(number / (int)Math.pow(base, position))] + result;
    } else
    {
      int remainder = (number % (int)Math.pow(base, position + 1));
      return convert (  number - remainder, base, position + 1, symbols[remainder / (int)( Math.pow(base, position) )] + result );
    }
  }
  //String convert(int num, int base) {
  //  int q = num / base;
  //  int rem = num % base;

  //  if (q == 0) {
  //    return Integer.toString(rem);
  //  } else {
  //    return convert(q, base) + Integer.toString(rem);
  //  }
  //}

  // Fibonacci Numbers
  public boolean isFibonacci(int num) {
    int fib1 = 0;
    int fib2 = 1;
    do {
      int saveFib1 = fib1;
      fib1 = fib2;
      fib2 = saveFib1 + fib2;
    } while (fib2 < num);

    if (fib2 == num)
      return true;
    else
      return false;
  }

  // Catalan Numbers
  /**Generates a list of the first 10 Catalan numbers
   * 
   * @return Array of first 10 Catalan numbers
   */
  public int[] makeCatalan() {
    int[] returnVal = new int[10];

    for (int i=1; i<11; i++) {
      returnVal[i-1]= Integer.valueOf(factorial(2*i).divide(factorial(i+1).multiply(factorial(i))).toString());
    }

    return returnVal;
  }
  /**Tests to see if a number is a Catalan Number
   * Definition here : https://en.wikipedia.org/wiki/Catalan_number
   * 
   * @param n Number to test if Catalan
   * @return Whether or not a number is a Catalan #
   */
  public boolean isCatalan(int n) {
    for (int i : catalan) {
      if (i==n) return true;
    }
    return false;
  }

  /**Tests to see if a given paramater is a Hamming number
   * Hamming number if the only prime factors of that number are 2, 3, or 5
   * 
   * @param n Number to test if a Hamming Number
   * @return if the Number is a Hamming Number
   */
  public boolean isHamming(int n) {
    int num = n;
    while (num%5==0) {
      num=num/5;
    }
    while (num%3==0) {
      num=num/3;
    }

    while (num % 2==0) {
      num=num/2;
    }
    if (num==1) {
      return true;
    } else {
      return false;
    }
  }

  // Returns the instance of the prime that is looked up
  public void allPrimesLessThanN(int n) {
    primeList = new ArrayList();
    for (int i = 1; i <= n; i ++) {
      if (isPrime(i))
        primeList.add(i);
    }
  }

  public BigInteger factorial(int n) {
    BigInteger convertToRet = new BigInteger("1");
    for (int i=1; i<=n; i++) {
      convertToRet = convertToRet.multiply(new BigInteger(String.valueOf(i)));
    }
    return convertToRet;
  }

  public void bellGenerator() {
    bell[0] = 1;
    bell[1] = 1;
    for (int i=2; i<bell.length; i++) {
      bell[i] = recurrBell(i);
    }
  }

  public int nComb(int n, int k) {
    BigInteger result;
    result = factorial(n).divide(factorial(k).multiply(factorial(n-k)));

    return result.intValue();
  }

  public int recurrBell(int n) {
    int sum = 0;
    for (int i=0; i<n; i++) {
      sum += nComb(n-1, i)*bell[i];
    }
    return sum;
  }

  public boolean isBell(int n) {
    for (int i : bell) {
      if (i==n) return true;
    }
    return false;
  }

  // Returns the previous prime
  public int nextPrime(int num) {
    int retval = 0;
    if (isPrime(num)) {
      retval=primeList.get(num);
      return retval;
    } else {
      retval=primeList.get(num-1);
      return retval;
    }
  }
}
  public void settings() {  size(360, 330); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Calculator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
